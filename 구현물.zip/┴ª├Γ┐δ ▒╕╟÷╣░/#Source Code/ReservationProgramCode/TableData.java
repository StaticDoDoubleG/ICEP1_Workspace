package ReservationProgram;

public class TableData {
	public int tableNum;
	public int accommodatablePeople;
}
