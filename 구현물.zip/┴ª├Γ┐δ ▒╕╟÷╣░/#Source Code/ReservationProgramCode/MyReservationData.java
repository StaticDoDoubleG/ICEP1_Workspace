package ReservationProgram;

public class MyReservationData {
	public int indexInFile;
	public ReservationData data;
}
