package ReservationProgram;

public class ReservationData {
	public int userAccountIndex;
	public Time time;
	public int people;
	public int tableNum;
	public int reservationNum;
	public String status;
	public OrderedMenuInfo orderedMenu;
	public int restaurantIndex;
	//menu
	//restaurant
}
