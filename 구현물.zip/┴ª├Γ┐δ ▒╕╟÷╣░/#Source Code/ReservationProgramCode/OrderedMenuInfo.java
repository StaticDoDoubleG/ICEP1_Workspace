package ReservationProgram;

public class OrderedMenuInfo {
	public int[] menuIndex;
	public int[] orderedAmount;

	public OrderedMenuInfo(int[] menuIndex, int[] orderedAmount) {
		this.menuIndex=menuIndex;
		this.orderedAmount=orderedAmount;
	}

}
