package ReservationProgram;

public class MenuInfo {
	public String[] menuName;
	public int[] menuPrice;
	
	public MenuInfo(String[] menuName, int[] menuPrice) {
		this.menuName=menuName;
		this.menuPrice=menuPrice;
	}
}
