package AdminProgram;

public class ReservationData {
	public String userAccountIndex;
	public String date;
	public String time;
	public String people;
	public String tableNum;
	public String reservationNum;
	public String status;
	public int restaurant;
	public String menu;
}
