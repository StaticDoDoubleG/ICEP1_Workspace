package AdminProgram;

public class Admin {
	public String id;
	public String pw;
	
	public Admin() {	
	}
	
	public Admin(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}

	
}
