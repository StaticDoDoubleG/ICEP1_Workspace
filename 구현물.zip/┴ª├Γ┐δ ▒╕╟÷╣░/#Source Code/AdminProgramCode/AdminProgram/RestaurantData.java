package AdminProgram;

public class RestaurantData {
	public String RestaurantName;
	public String Menu;
	
	public RestaurantData() {
		
	}
	
	public RestaurantData(String rName, String Menu) {
		this.RestaurantName = rName;
		this.Menu = Menu;
	}
}
